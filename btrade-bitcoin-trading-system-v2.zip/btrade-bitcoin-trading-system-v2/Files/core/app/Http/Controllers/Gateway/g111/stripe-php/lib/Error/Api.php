<?php

namespace StripeJS\Error;

class Api extends Base
{
}
