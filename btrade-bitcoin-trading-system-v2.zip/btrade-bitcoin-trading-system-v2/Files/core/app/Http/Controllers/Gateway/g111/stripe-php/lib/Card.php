<?php

namespace StripeJS;

/**
 * Class Card
 *
 * @package StripeJS
 */
class Card extends ExternalAccount
{

}
