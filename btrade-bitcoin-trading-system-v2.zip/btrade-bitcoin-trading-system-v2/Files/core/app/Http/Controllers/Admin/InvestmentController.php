<?php

namespace App\Http\Controllers\Admin;

use App\Plan;
use App\Compound;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Image;
class InvestmentController extends Controller
{
    public function createPlan()
    {
        $data['page_title'] = "New Investment Plan";
       
        return view('dashboard.plan-create', $data);
    }
    public function storePlan(Request $request)
    {
        $this->validate($request,[
            'name' => 'required|unique:plans,name',
            'minimum' => 'required|numeric|integer',
            'maximum' => 'required|numeric|integer|gt:minimum',
            'time' => 'required|integer',
            'compound_id' => 'required',
            'percent' => 'required|numeric',
        ]);
        $plan = request()->except('_method','_token');
        $plan['status'] = $request->status == 'on' ? '1' : '0';
        Plan::create($plan);
        $notify[]=['success','Plan created successfully'];
        return back()->withNotify($notify);
    }


    public function showPlan()
    {
        $invests['page_title'] = "All Investment Plan";
        $invests['empty_message'] = "No plans";
        $invests['compound'] = Compound::all();
        $invests['plans'] = Plan::paginate(10);
        return view('admin.investment.allPlans', $invests);
    }


    public function editPlan($id)
    {
        $data['page_title'] = "All Investment Plan";
        $data['plan'] = Plan::findOrFail($id);
        $data['compound'] = Compound::all();
        return view('dashboard.plan-edit', $data);
    }
    public function updatePlan(Request $request,$id)
    {
        $p = Plan::findOrFail($id);
        $this->validate($request,[
            'name' => 'required',
            'minimum' => 'required|numeric|integer',
            'maximum' => 'required|numeric|integer|gt:minimum',
            'time' => 'required|integer',
            'compound_id' => 'required',
            'percent' => 'required|numeric',
        ]);
       
        $plan = request()->except('_method','_token');
        $plan['status'] = $request->status ? 1 : 0;
        $p->fill($plan)->save();
        $notify[]=['success','Plan updated successfully'];
        return back()->withNotify($notify);
    }

    public function search(Request $request)
    {
        $search  = $request->search;
        $data['plans'] = Plan::where('name','like',"% $search%")->latest()->paginate(10);
        $data['page_title'] = "Search Result :  $search";
        return view('admin.investment.allPlans', $data);
    }
    
}
