<?php

namespace App\Http\Controllers;

use Auth;
use App\Trx;
use App\Page;
use App\User;
use App\Repeat;
use App\Frontend;
use App\Language;
use App\RepeatLog;
use Carbon\Carbon;
use App\Investment;
use App\Subscriber;
use App\SupportTicket;
use App\GeneralSetting;
use App\SupportMessage;
use App\SupportAttachment;
use Illuminate\Support\Str;
use Illuminate\Http\Request;

class SiteController extends Controller
{
    public function home()
    {
        $count = Page::where('tempname',activeTemplate())->where('slug','home')->count();
        if($count == 0){
            $in['tempname'] = activeTemplate();
            $in['name'] = 'HOME';
            $in['slug'] = 'home';
            Page::create($in);
        }

        $data['page_title'] = 'Home';
        $data['sections'] = Page::where('tempname',activeTemplate())->where('slug','home')->firstOrFail();
        return view(activeTemplate() . 'home', $data);
    }

    public function pages($slug)
    {
        $page = Page::where('tempname',activeTemplate())->where('slug',$slug)->firstOrFail();
        $data['page_title'] = $page->name;
        $data['sections'] = $page;
        return view(activeTemplate() . 'pages', $data);
    }

    public function register($reference)
    {
        $page_title = "Sign Up";
        return view(activeTemplate() . 'user.auth.register', compact('reference', 'page_title'));
    }

    public function changeLang($lang)
    {
        $language = Language::where('code', $lang)->first();
        if (!$language) $lang = 'en';
        session()->put('lang', $lang);
        return redirect()->back();
    }


    public function blog()
    {
        $blogs = Frontend::where('data_keys', 'blog.element')->latest()->paginate(9);
        $recentBlog = Frontend::where('data_keys', 'blog.element')->latest()->limit(8)->get();
        $page_title = "Blog";
        return view(activeTemplate() . 'blog', compact('blogs', 'page_title', 'recentBlog'));
    }

    public function blogDetails($slug = null, $id, $data_keys = 'blog.element')
    {
        $post = Frontend::where('id', $id)->where('data_keys', $data_keys)->firstOrFail();
        $page_title = "Blog Details";
        $data['title'] = $post->data_values->title;
        $data['details'] = $post->data_values->description;
        $data['image'] =  asset('assets/images/frontend/blog/'.$post->data_values->image);
        $recentBlog = Frontend::where('data_keys', 'blog.element')->latest()->limit(8)->get();
        return view(activeTemplate() . 'blog-details', compact('recentBlog', 'post', 'data', 'page_title'));
    }
    public function contact()
    {
        $data['page_title'] = "Contact Us";
        $data['contact'] = Frontend::where('data_keys', 'contact_us.content')->firstOrFail();
        return view(activeTemplate() . 'contact', $data);
    }

    public function faqSection()
    {
        $page_title = "Frequently Asked Questions";
        $faqs = Frontend::where('data_keys', 'faq.element')->latest()->get();
        return view(activeTemplate().'sections.faq',compact('faqs','page_title'));

    }
    
    public function contactSubmit(Request $request)
    {
        $ticket = new SupportTicket();
        $message = new SupportMessage();

        $imgs = $request->file('attachments');
        $allowedExts = array('jpg', 'png', 'jpeg', 'pdf');

        $validator = $this->validate($request, [
            'attachments' => [
                'sometimes',
                'max:4096',
                function ($attribute, $value, $fail) use ($imgs, $allowedExts) {
                    foreach ($imgs as $img) {
                        $ext = strtolower($img->getClientOriginalExtension());
                        if (($img->getSize() / 1000000) > 2) {
                            return $fail("Images MAX  2MB ALLOW!");
                        }
                        if (!in_array($ext, $allowedExts)) {
                            return $fail("Only png, jpg, jpeg, pdf images are allowed");
                        }
                    }
                    if (count($imgs) > 5) {
                        return $fail("Maximum 5 images can be uploaded");
                    }
                },
            ],
            'name' => 'required|max:191',
            'email' => 'required|max:191',
            'subject' => 'required|max:100',
            'message' => 'required',
        ]);



        $random = getNumber();

        if(Auth::user()){
          
            $ticket->user_id = Auth::id();
            $ticket->name = Auth::user()->fullname;
            $ticket->email = Auth::user()->email;
        }else{
           
            $ticket->user_id = null;
            $ticket->name = $request->name;
            $ticket->email = $request->email;
        }



        $ticket->ticket = $random;
        $ticket->subject = $request->subject;
        $ticket->last_reply = Carbon::now();
        $ticket->status = 0;
        $ticket->save();

        $message->supportticket_id = $ticket->id;
        $message->message = $request->message;
        $message->save();


        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $image) {
                $filename = rand(1000, 9999) . time() . '.' . $image->getClientOriginalExtension();
                $image->move('assets/images/support', $filename);
                SupportAttachment::create([
                    'support_message_id' => $message->id,
                    'image' => $filename,
                ]);
            }
        }
        $notify[] = ['success', 'ticket created successfully!'];

        return redirect()->route('ticket.view',[$ticket->ticket])->withNotify($notify);

    }


    public function subscribe(Request $request)
    {
        $request->validate([
            'email' => 'required|email|max:255',
        ]);

        $macCount = Subscriber::where('email', trim(strtolower($request->email)))->count();
        if ($macCount > 0) {
            $notify[] = ['error', 'This Email Already Exist !!'];
            return redirect()->to(url()->previous() . "#subscribe")->withNotify($notify)->withInput();

        } else {
            Subscriber::create($request->only('email'));
            $notify[] = ['success', 'Subscribe Successfully!'];
            return redirect()->to(url()->previous() . "#subscribe")->withNotify($notify);

        }
    }

    public function links($slug,$id)
    {
        
        $link = Frontend::where('id',$id)->where('data_keys','links.element')->first();
        $page_title = $link->data_values->title;
        return view(activeTemplate().'linkDetails',compact('page_title','link'));
    }

    public function repeatGenerate()
    {
        $basic = GeneralSetting::first();
        if($basic->repeat_status != 1){
            exit;
        }
         
            $repeats = Repeat::whereStatus(0)->get();

            foreach ($repeats as $rep){
                if ($rep->repeat_time < Carbon::now()){

                    $rLog['user_id'] = $rep->user_id;
                    $rLog['trx_id'] = strtoupper(Str::random(20));
                    $rLog['investment_id'] = $rep->investment_id;
                    $rLog['made_time'] = Carbon::now();
                    $rLog['amount'] = round(($rep->invest->amount * $rep->invest->plan->percent) / 100,$basic->deci);
                    RepeatLog::create($rLog);

                    $rep->total_repeat = $rep->total_repeat + 1;
                    $rep->made_time = Carbon::now();
                    $rep->repeat_time = Carbon::parse()->addHours($rep->invest->plan->compound->compound);
                    if ($rep->total_repeat == $rep->invest->plan->time){
                        $rep->status = 1;
                        $inv = Investment::findOrFail($rep->investment_id);
                        $inv->status = 1;
                        $inv->save();
                    }

                    $rep->save();

                    $amo = $rLog['amount'];
                    $plan = $rep->invest->plan->name;
                    $trx = $rLog['trx_id'];

                    $mem = User::findOrFail($rep->user_id);

                    $ul['user_id'] = $rep->user_id;
                    $ul['amount'] = $rLog['amount'];
                    $ul['charge'] = null;
                    $ul['trx_type'] = '+';
                    $ul['post_balance'] = $mem->balance + $amo;
                    $ul['amount_type'] = 15;
                    $ul['details'] = "Repeat ".$amo." ".$basic->currency.". For Investment Plan - $plan.";
                    $ul['trx'] = $trx;
                    $ul['remark'] = 'investment repeat';
                    Trx::create($ul);

                    $mem->balance = $mem->balance + $amo;
                    $mem->save();

                    if ($basic->email_notify == 1){
                        $text = $amo." - ". $basic->cur_text ." Repeat For Investment Plan - $plan. <br> Transaction ID Is : <b>#".$trx."</b>";
                        $this->sendMail($mem->email,$mem->name,'Investment Repeat Bonus.',$text);
                    }
                    if ($basic->phone_notify == 1){
                        $text = $amo." - ".$basic->cur_text ." Repeat For Investment Plan - $plan. <br> Transaction ID Is : <b>#".$trx."</b>";
                        $this->sendSms($mem->phone,$text);
                    }

                

                }
            }
        
    }
}
