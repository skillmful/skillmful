<?php

namespace App\Http\Controllers;

use App\Trx;
use App\Plan;
use App\User;
use App\Repeat;
use App\Compound;
use App\RepeatLog;
use Carbon\Carbon;
use App\Investment;
use App\GeneralSetting;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\Console\Input\Input;


class InvestmentController extends Controller
{
    public function newInvest()
    {
       
        $data['page_title'] = "User New Invest";
        $data['plans'] = Plan::whereStatus(1)->get();
        return view(activeTemplate().'user.investment.newInvest',$data);
    }

    public function postInvest(Request $request)
    {
        $this->validate($request,[
            'id' => 'required'
        ]);
        $data['page_title'] = "Investment Preview";
        $data['plan'] = Plan::findOrFail($request->id);
        return view('user.investment-preview',$data);
    }

    public function chkInvestAmount(Request $request)
    {
        $plan = Plan::findOrFail($request->plan);
        $user = User::findOrFail(Auth::user()->id);
        $amount = $request->amount;

        if ($request->amount > $user->balance){
            return '
                <div class="alert alert-warning"><i class="fa fa-times"></i> Amount Is Larger than Your Current Balance.</div>';
        }
        if( $plan->minimum > $amount){
            return ' <div class="alert alert-warning"><i class="fa fa-times"></i> Amount Is Smaller than Plan Minimum Amount.</div>';
        }elseif( $plan->maximum < $amount){
            return '<div class="alert alert-warning"><i class="fa fa-times"></i> Amount Is Larger than Plan Maximum Amount.</div>';
        }else{
            return '<div class="alert alert-success"><i class="fa fa-check"></i> Well Done. Invest Under this Package.</div>'; 
        }

    }

    public function submitInvest(Request $request)
    {
        $basic = GeneralSetting::first();
        $request->validate([
            'amount' => 'required',
            'user_id' => 'required',
            'plan_id' => 'required'
        ]);
        $in = request()->except('_method','_token');
        $in['trx_id'] = strtoupper(Str::random(12));
        $invest = Investment::create($in);
       
        $pak = Plan::findOrFail($request->plan_id);
        $com = Compound::findOrFail($pak->compound_id);
        $rep['user_id'] = $invest->user_id;
        $rep['investment_id'] = $invest->id;
        $rep['repeat_time'] = Carbon::parse()->addHours($com->compound);
        $rep['total_repeat'] = 0;
        Repeat::create($rep);

        $bal4 = User::findOrFail(Auth::user()->id);
        $ul['user_id'] = $bal4->id;
        $ul['amount'] = $request->amount;
        $ul['charge'] = 0;
        $ul['trx_type'] = '-';
        $ul['amount_type'] = 14;
        $ul['post_balance'] = $bal4->balance - $request->amount;
        $ul['details'] = $request->amount." ".$basic->currency." Invest Under ".$pak->name." Plan.";
        $ul['trx'] = $in['trx_id'];
        $ul['remark'] = 'investment';
        Trx::create($ul);

        $bal4->balance = $bal4->balance - $request->amount;
        $bal4->save();

        $trx = $in['trx_id'];

        if ($basic->email_notify == 1){
            $text = $request->amount." - ". $basic->currency." Invest Under ".$pak->name." Plan. <br> Transaction ID Is : <b>#$trx</b>";
            $this->sendMail($bal4->email,$bal4->name,'New Investment',$text);
        }
        if ($basic->phone_notify == 1){
            $text = $request->amount." - ". $basic->currency." Invest Under ".$pak->name." Plan. <br> Transaction ID Is : <b>#$trx</b>";
            $this->sendSms($bal4->phone,$text);
        }
        $notify[]=['success',' Investment Successfully Completed'];
        return back()->withNotify($notify);
    }

    public function historyInvestment()
    {
        $data['page_title'] = "Invest History";
        $data['histories'] = Investment::whereUser_id(Auth::user()->id)->latest()->paginate(15);
        return view(activeTemplate().'user.investment.investHistory',$data);
    }

    public function repeatLog()
    {
        $data['user'] = User::findOrFail(Auth::user()->id);
        $data['page_title'] = 'All Repeat';
        $data['logs'] = RepeatLog::whereUser_id(Auth::user()->id)->latest()->paginate(15);
        return view(activeTemplate().'user.investment.repeatHistory',$data);
    }
}
