<?php
header("Content-Type:text/css");
$color = "#f0f"; // Change your Color Here
$secondColor = "#ff8"; // Change your Color Here
function checkhexcolor($color){
    return preg_match('/^#[a-f0-9]{6}$/i', $color);
}
if (isset($_GET['color']) AND $_GET['color'] != '') {
    $color = "#" . $_GET['color'];
}
if (!$color OR !checkhexcolor($color)) {
    $color = "#336699";
}
function checkhexcolor2($secondColor){
    return preg_match('/^#[a-f0-9]{6}$/i', $secondColor);
}
if (isset($_GET['secondColor']) AND $_GET['secondColor'] != '') {
    $secondColor = "#" . $_GET['secondColor'];
}
if (!$secondColor OR !checkhexcolor2($secondColor)) {
    $secondColor = "#336699";
}

?>

.header-top, .cmn-btn, .header-category, .footer-widget .title::after,.scrollToTop::before, .scrollToTop::after, .ui-slider, .refer-nav .refer-next:hover, .refer-nav .refer-next.active, .refer-nav .refer-prev:hover, .refer-nav .refer-prev.active, .header-section.active, .cmn-btn, .dashboard-item .dashboard-icon, .cmn-table-2 th, .menu li .submenu li:hover > a, .preloader, .header-category::before{
    background:<?php echo $color; ?> !important
}

.header-top, .client-content::before, .footer-widget ul li a i, .footer-bottom .copyright a, .pricing-item .pricing-header .name, .dashboard-item .dashboard-content .subtitle,.cl-theme, p a:hover, p a{
    color: <?php echo $color; ?> !important
}

.cmn-table-1 tbody tr{
    border-top: <?php echo $color; ?> !important
}

.cmn-btn{
    border:1px solid <?php echo $color; ?> !important
}

.cmn-btn:hover{

   border-color:<?php echo $color; ?> !important
}






.video-button, .video-button::before, .video-button::after,.referral-item .header{
    background:<?php echo $secondColor; ?> !important
}

.cl-2{
    color: <?php echo $secondColor; ?> !important
}
